package np.school.digitalbell

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        try {
            val svc = Intent(ctx, BellService::class.java).setAction(BellService.ACTION_PLAY)
                .putExtra("label", intent.getStringExtra("label"))
                .putExtra("sound", intent.getStringExtra("sound"))
                .putExtra("duration", intent.getIntExtra("duration", 5))
            if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(svc) else ctx.startService(svc)
        } finally {
            Scheduler.scheduleNext(ctx) // always arm the following bell
        }
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        Scheduler.scheduleNext(ctx)
    }
}
