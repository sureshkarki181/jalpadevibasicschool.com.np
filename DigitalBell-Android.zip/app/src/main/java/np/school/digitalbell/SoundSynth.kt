package np.school.digitalbell

import android.content.Context
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder

// Generates the four bell sounds as small looping WAV files (no audio assets needed).
object SoundSynth {
    private const val SR = 22050

    fun file(ctx: Context, sound: String): File {
        val key = if (sound in listOf("electric", "gong", "chime", "siren")) sound else "electric"
        val f = File(ctx.filesDir, "snd_${key}_v1.wav")
        if (!f.exists() || f.length() < 1000) f.writeBytes(toWav(render(key)))
        return f
    }

    private fun render(k: String): FloatArray = when (k) {
        "gong" -> gong()
        "chime" -> chime()
        "siren" -> siren()
        else -> electric()
    }

    // Adds a decaying sine into the buffer, wrapping around so the loop is seamless
    private fun tone(buf: FloatArray, startSec: Double, f: Double, amp: Double, attack: Double, decay: Double, lenSec: Double) {
        val n = (lenSec * SR).toInt()
        val s0 = (startSec * SR).toInt()
        for (i in 0 until n) {
            val t = i.toDouble() / SR
            val env = if (t < attack) t / attack else Math.exp(-6.9 * (t - attack) / decay)
            buf[(s0 + i) % buf.size] += (amp * env * Math.sin(2 * Math.PI * f * t)).toFloat()
        }
    }

    private fun electric(): FloatArray {
        val buf = FloatArray((1.1 * SR).toInt())
        val freqs = doubleArrayOf(1180.0, 2375.0, 3680.0, 5140.0)
        val amps = doubleArrayOf(0.35, 0.25, 0.18, 0.12)
        for (i in 0 until 20) for (p in freqs.indices) tone(buf, i * 0.055, freqs[p], amps[p], 0.004, 0.065, 0.07)
        return buf
    }

    private fun gong(): FloatArray {
        val buf = FloatArray((3.5 * SR).toInt())
        val parts = arrayOf(doubleArrayOf(310.0, 0.45, 1.8), doubleArrayOf(622.0, 0.30, 1.5),
            doubleArrayOf(948.0, 0.22, 1.2), doubleArrayOf(1475.0, 0.16, 0.9), doubleArrayOf(2210.0, 0.10, 0.6))
        for (s in doubleArrayOf(0.0, 1.75)) for (p in parts) tone(buf, s, p[0], p[1], 0.012, p[2], p[2] + 0.05)
        return buf
    }

    private fun chime(): FloatArray {
        val notes = doubleArrayOf(523.25, 659.25, 783.99, 1046.50, 783.99, 659.25, 523.25)
        val buf = FloatArray((notes.size * 0.55 * SR).toInt())
        for (i in notes.indices) {
            tone(buf, i * 0.55, notes[i], 0.35, 0.02, 1.1, 1.15)
            tone(buf, i * 0.55, notes[i] * 2, 0.17, 0.02, 1.1, 1.15)
        }
        return buf
    }

    private fun siren(): FloatArray {
        val n = (1.2 * SR).toInt()
        val buf = FloatArray(n)
        var ph = 0.0
        for (i in 0 until n) {
            val t = i.toDouble() / n * 2
            val f = if (t < 1) 560 + 620 * t else 1180 - 620 * (t - 1)
            ph += f / SR
            var v = 0.0
            val kmax = minOf(4, (1800 / f).toInt())
            for (k in 1..kmax) v += Math.sin(2 * Math.PI * k * ph) / k
            buf[i] = (0.5 * v).toFloat()
        }
        return buf
    }

    private fun toWav(buf: FloatArray): ByteArray {
        var peak = 0f
        for (x in buf) peak = maxOf(peak, Math.abs(x))
        val g = if (peak > 0f) 0.9f / peak else 1f
        val data = ByteBuffer.allocate(buf.size * 2).order(ByteOrder.LITTLE_ENDIAN)
        for (x in buf) data.putShort((x * g * 32767).toInt().coerceIn(-32768, 32767).toShort())
        val out = ByteBuffer.allocate(44 + buf.size * 2).order(ByteOrder.LITTLE_ENDIAN)
        out.put("RIFF".toByteArray()); out.putInt(36 + buf.size * 2)
        out.put("WAVE".toByteArray()); out.put("fmt ".toByteArray())
        out.putInt(16); out.putShort(1); out.putShort(1); out.putInt(SR); out.putInt(SR * 2)
        out.putShort(2); out.putShort(16)
        out.put("data".toByteArray()); out.putInt(buf.size * 2)
        out.put(data.array())
        return out.array()
    }
}
