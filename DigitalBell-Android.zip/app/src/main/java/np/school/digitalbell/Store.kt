package np.school.digitalbell

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class Bell(val id: String, var time: String, var label: String, var sound: String, var duration: Int, var enabled: Boolean)

object Store {
    val MODES = listOf("regular" to "नियमित", "halfday" to "आधा दिन", "exam" to "परीक्षा", "custom" to "कस्टम")
    val SOUNDS = listOf("electric" to "इलेक्ट्रिक घण्टी", "gong" to "परम्परागत गोङ", "chime" to "मधुर धुन", "siren" to "आकस्मिक साइरन")

    class State {
        var name = "श्री जाल्पादेवी आधारभूत विद्यालय"
        var subtitle = "चम्पादेवी-१, महारुद्रभञ्ज्याङ, ओखलढुङ्गा"
        var mode = "regular"
        var holiday = false
        var satOff = true
        var sunOff = false
        val schedules: MutableMap<String, MutableList<Bell>> = mutableMapOf()
    }

    private fun b(id: String, t: String, l: String, s: String, d: Int) = Bell(id, t, l, s, d, true)

    fun defaults(): State {
        val st = State()
        st.schedules["regular"] = mutableListOf(
            b("r1", "10:00", "प्रार्थना / राष्ट्रिय गान", "chime", 6),
            b("r2", "10:15", "पहिलो घण्टी", "electric", 4),
            b("r3", "11:00", "दोस्रो घण्टी", "electric", 4),
            b("r4", "11:45", "तेस्रो घण्टी", "electric", 4),
            b("r5", "12:30", "चौथो घण्टी", "electric", 4),
            b("r6", "13:15", "टिफिन / खाजा समय", "gong", 6),
            b("r7", "14:00", "पाँचौँ घण्टी", "electric", 4),
            b("r8", "14:45", "छैटौँ घण्टी", "electric", 4),
            b("r9", "15:30", "सातौँ घण्टी", "electric", 4),
            b("r10", "16:00", "छुट्टी घण्टी", "gong", 8)
        )
        st.schedules["halfday"] = mutableListOf(
            b("h1", "10:00", "प्रार्थना / राष्ट्रिय गान", "chime", 6),
            b("h2", "10:15", "पहिलो घण्टी", "electric", 4),
            b("h3", "11:00", "दोस्रो घण्टी", "electric", 4),
            b("h4", "11:45", "तेस्रो घण्टी", "electric", 4),
            b("h5", "12:30", "चौथो घण्टी", "electric", 4),
            b("h6", "13:30", "छुट्टी घण्टी (आधा दिन)", "gong", 8)
        )
        st.schedules["exam"] = mutableListOf(
            b("e1", "10:00", "प्रवेश घण्टी", "chime", 5),
            b("e2", "10:15", "परीक्षा सुरु", "electric", 6),
            b("e3", "11:15", "१ घण्टा पूरा", "gong", 3),
            b("e4", "12:15", "२ घण्टा पूरा", "gong", 3),
            b("e5", "13:00", "१५ मिनेट बाँकी", "electric", 4),
            b("e6", "13:15", "परीक्षा समाप्त", "gong", 8)
        )
        st.schedules["custom"] = mutableListOf(
            b("c1", "10:30", "प्रार्थना (कस्टम समय)", "chime", 6),
            b("c2", "10:45", "पहिलो घण्टी", "electric", 4),
            b("c3", "15:30", "छुट्टी घण्टी", "gong", 8)
        )
        return st
    }

    // Reads both this app's own format and the web page's backup JSON
    fun parse(j: JSONObject): State {
        val st = defaults()
        j.optJSONObject("school")?.let {
            st.name = it.optString("name", st.name)
            st.subtitle = it.optString("subtitle", st.subtitle)
        }
        val m = j.optString("activeMode", st.mode)
        if (MODES.any { it.first == m }) st.mode = m
        j.optJSONObject("settings")?.let { s ->
            st.holiday = s.optBoolean("holidayPause", false)
            val both = s.optBoolean("autoOffWeekend", false)
            st.satOff = s.optBoolean("satOff", both)
            st.sunOff = s.optBoolean("sunOff", both)
        }
        j.optJSONObject("schedules")?.let { sc ->
            for ((key, _) in MODES) {
                val arr = sc.optJSONArray(key) ?: continue
                val list = mutableListOf<Bell>()
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    val sound = o.optString("sound", "electric").let { s -> if (SOUNDS.any { it.first == s }) s else "electric" }
                    list.add(Bell(o.optString("id", "b$i-${System.nanoTime()}"), o.optString("time", "10:00"),
                        o.optString("label", "घण्टी"), sound, o.optInt("duration", 5).coerceIn(1, 120), o.optBoolean("enabled", true)))
                }
                st.schedules[key] = list
            }
        }
        return st
    }

    fun toJson(st: State): JSONObject {
        val o = JSONObject()
        o.put("school", JSONObject().put("name", st.name).put("subtitle", st.subtitle))
        o.put("activeMode", st.mode)
        o.put("settings", JSONObject().put("holidayPause", st.holiday)
            .put("autoOffWeekend", st.satOff && st.sunOff).put("satOff", st.satOff).put("sunOff", st.sunOff))
        val sc = JSONObject()
        for ((k, list) in st.schedules) {
            val arr = JSONArray()
            for (b in list) arr.put(JSONObject().put("id", b.id).put("time", b.time).put("label", b.label)
                .put("sound", b.sound).put("duration", b.duration).put("enabled", b.enabled))
            sc.put(k, arr)
        }
        o.put("schedules", sc)
        return o
    }

    fun load(ctx: Context): State {
        val raw = ctx.getSharedPreferences("bell", 0).getString("state", null) ?: return defaults()
        return try { parse(JSONObject(raw)) } catch (e: Exception) { defaults() }
    }

    fun save(ctx: Context, st: State) {
        ctx.getSharedPreferences("bell", 0).edit().putString("state", toJson(st).toString()).apply()
    }
}
