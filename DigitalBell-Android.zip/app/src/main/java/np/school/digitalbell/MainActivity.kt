package np.school.digitalbell

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.NotificationManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView
import android.widget.TimePicker
import android.widget.Toast
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var st: Store.State
    private lateinit var root: LinearLayout
    private val reqImport = 11
    private val reqExport = 12
    private val days = listOf("आइतबार", "सोमबार", "मंगलबार", "बुधबार", "बिहीबार", "शुक्रबार", "शनिबार")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        val sv = ScrollView(this)
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(24), dp(16), dp(40))
        }
        sv.addView(root)
        setContentView(sv)
    }

    override fun onResume() {
        super.onResume()
        st = Store.load(this)
        Scheduler.scheduleNext(this)
        render()
    }

    // ---------- helpers ----------
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun add(v: View) = root.addView(v, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
    private fun tv(s: String, size: Float = 15f, bold: Boolean = false) = TextView(this).apply {
        text = s; textSize = size; setPadding(0, dp(4), 0, dp(4))
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }
    private fun btn(s: String, f: () -> Unit) = Button(this).apply { text = s; isAllCaps = false; setOnClickListener { f() } }
    private fun small(s: String, f: () -> Unit) = Button(this).apply {
        text = s; minWidth = dp(44); minimumWidth = dp(44); setOnClickListener { f() }
    }
    private fun sw(label: String, v: Boolean, f: (Boolean) -> Unit) = Switch(this).apply {
        text = label; isChecked = v; setPadding(0, dp(8), 0, dp(8)); setOnCheckedChangeListener { _, c -> f(c) }
    }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    private fun soundName(k: String) = Store.SOUNDS.firstOrNull { it.first == k }?.second ?: k

    private fun fmtHm(t: String): String {
        val p = t.split(":")
        val h = p.getOrNull(0)?.toIntOrNull() ?: return t
        val m = p.getOrNull(1)?.toIntOrNull() ?: return t
        return "%02d:%02d %s".format(if (h % 12 == 0) 12 else h % 12, m, if (h >= 12) "PM" else "AM")
    }
    private fun fmtMs(ms: Long): String {
        val c = Calendar.getInstance().apply { timeInMillis = ms }
        return days[c.get(Calendar.DAY_OF_WEEK) - 1] + " " + SimpleDateFormat("hh:mm a", Locale.US).format(Date(ms))
    }

    private fun commit() {
        Store.save(this, st)
        Scheduler.scheduleNext(this)
        root.post { render() }
    }

    private fun ring(label: String, sound: String, dur: Int) {
        val i = Intent(this, BellService::class.java).setAction(BellService.ACTION_PLAY)
            .putExtra("label", label).putExtra("sound", sound).putExtra("duration", dur)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
    }
    private fun stopRing() {
        startService(Intent(this, BellService::class.java).setAction(BellService.ACTION_STOP))
    }

    // ---------- screen ----------
    private fun render() {
        root.removeAllViews()
        add(tv(st.name, 20f, true))
        add(tv(st.subtitle, 13f))

        val nb = Scheduler.nextBell(st)
        add(tv(if (nb == null) "अर्को घण्टी: छैन (बिदा वा सबै घण्टी बन्द)"
               else "अर्को घण्टी: ${nb.second.label} • ${fmtMs(nb.first)}", 16f, true))

        val pm = getSystemService(POWER_SERVICE) as PowerManager
        if (!pm.isIgnoringBatteryOptimizations(packageName)) {
            add(tv("⚠ ब्याट्री अप्टिमाइजेसन खुला छ — घण्टी नबज्न सक्छ। तल थिचेर 'अनुमति दिनुहोस्' गर्नुहोस्।", 14f))
            add(btn("ब्याट्री अप्टिमाइजेसन हटाउनुहोस् (आवश्यक)") {
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
            })
        }
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26 && !nm.areNotificationsEnabled()) {
            add(tv("⚠ सूचना (Notification) बन्द छ। खोल्नुहोस्, नत्र 'रोक्नुहोस्' बटन देखिँदैन।", 14f))
            add(btn("सूचना सेटिङ खोल्नुहोस्") {
                startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, packageName))
            })
        }

        add(tv("समयतालिकाको मोड", 15f, true))
        val rg = RadioGroup(this)
        for ((k, label) in Store.MODES) {
            val rb = RadioButton(this)
            rb.text = label; rb.id = View.generateViewId(); rb.tag = k
            rg.addView(rb)
            if (k == st.mode) rb.isChecked = true
        }
        rg.setOnCheckedChangeListener { g, id ->
            val m = g.findViewById<RadioButton>(id).tag as String
            if (m != st.mode) { st.mode = m; commit() }
        }
        add(rg)

        add(sw("सार्वजनिक बिदा (सबै घण्टी बन्द)", st.holiday) { st.holiday = it; commit() })
        add(sw("शनिबार घण्टी बन्द", st.satOff) { st.satOff = it; commit() })
        add(sw("आइतबार घण्टी बन्द", st.sunOff) { st.sunOff = it; commit() })

        add(tv("घण्टीहरू (मोड: ${Store.MODES.first { it.first == st.mode }.second})", 15f, true))
        val list = st.schedules.getOrPut(st.mode) { mutableListOf() }
        for (b in list.sortedBy { it.time }) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            val s = Switch(this).apply { isChecked = b.enabled; setOnCheckedChangeListener { _, c -> b.enabled = c; commit() } }
            val info = TextView(this).apply {
                text = "${fmtHm(b.time)}  ${b.label}\n${soundName(b.sound)} • ${b.duration} से."
                textSize = 14f; setPadding(dp(8), dp(6), dp(8), dp(6))
                setOnClickListener { editBell(b) }
            }
            row.addView(s)
            row.addView(info, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(small("▶") { ring(b.label + " (परीक्षण)", b.sound, b.duration) })
            row.addView(small("✕") { confirmDelete(b) })
            add(row)
        }
        add(btn("+ नयाँ घण्टी थप्नुहोस्") { editBell(null) })

        add(tv("परीक्षण", 15f, true))
        add(btn("🔔 तत्काल घण्टी बजाउनुहोस्") { ring("तत्काल घण्टी (परीक्षण)", "electric", 4) })
        add(btn("⏹ घण्टी रोक्नुहोस्") { stopRing() })
        add(tv("घण्टीको आवाज फोनको 'Alarm volume' ले नियन्त्रण हुन्छ। फोन साइलेन्ट भए पनि अलार्म बज्छ, तर Alarm volume कम भए आवाज सानो आउँछ।", 12f))

        add(tv("ब्याकअप", 15f, true))
        add(btn("⬇ ब्याकअप (Export)") {
            startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE)
                .setType("application/json").putExtra(Intent.EXTRA_TITLE, "digital_bell_backup.json"), reqExport)
        })
        add(btn("⬆ रिस्टोर / वेब पेजको फाइल इम्पोर्ट") {
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*"), reqImport)
        })
    }

    private fun confirmDelete(b: Bell) {
        AlertDialog.Builder(this).setTitle("घण्टी हटाउने?").setMessage(b.label)
            .setPositiveButton("हटाउनुहोस्") { _, _ -> st.schedules[st.mode]?.remove(b); commit() }
            .setNegativeButton("रद्द", null).show()
    }

    private fun editBell(existing: Bell?) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0) }
        val tp = TimePicker(this).apply { setIs24HourView(true) }
        existing?.time?.split(":")?.let { p ->
            tp.hour = p.getOrNull(0)?.toIntOrNull() ?: 10
            tp.minute = p.getOrNull(1)?.toIntOrNull() ?: 0
        }
        val label = EditText(this).apply { hint = "घण्टीको नाम"; setText(existing?.label ?: "") }
        val spin = Spinner(this)
        spin.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, Store.SOUNDS.map { it.second })
        spin.setSelection(Store.SOUNDS.indexOfFirst { it.first == existing?.sound }.coerceAtLeast(0))
        val dur = EditText(this).apply {
            hint = "अवधि (सेकेन्ड, १–१२०)"; inputType = InputType.TYPE_CLASS_NUMBER
            setText((existing?.duration ?: 5).toString())
        }
        box.addView(tp); box.addView(label); box.addView(spin); box.addView(dur)
        val sv = ScrollView(this).apply { addView(box) }
        AlertDialog.Builder(this).setTitle(if (existing == null) "नयाँ घण्टी" else "घण्टी सम्पादन").setView(sv)
            .setPositiveButton("सुरक्षित") { _, _ ->
                tp.clearFocus()
                val time = "%02d:%02d".format(tp.hour, tp.minute)
                val name = label.text.toString().trim().ifEmpty { "घण्टी" }
                val sound = Store.SOUNDS[spin.selectedItemPosition].first
                val d = (dur.text.toString().toIntOrNull() ?: 5).coerceIn(1, 120)
                if (existing == null) {
                    st.schedules.getOrPut(st.mode) { mutableListOf() }
                        .add(Bell("b${System.currentTimeMillis()}", time, name, sound, d, true))
                } else {
                    existing.time = time; existing.label = name; existing.sound = sound; existing.duration = d
                }
                commit()
            }
            .setNegativeButton("रद्द", null).show()
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        try {
            if (requestCode == reqImport) {
                val txt = contentResolver.openInputStream(uri)!!.bufferedReader().use { it.readText() }
                val obj = JSONObject(txt)
                if (!obj.has("schedules")) { toast("अमान्य ब्याकअप फाइल।"); return }
                st = Store.parse(obj)
                commit()
                toast("समयतालिका रिस्टोर भयो।")
            } else if (requestCode == reqExport) {
                contentResolver.openOutputStream(uri)!!.bufferedWriter().use { it.write(Store.toJson(st).toString(2)) }
                toast("ब्याकअप सुरक्षित भयो।")
            }
        } catch (e: Exception) {
            toast("फाइल पढ्न/लेख्न सकिएन।")
        }
    }
}
