package np.school.digitalbell

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import java.util.Calendar

object Scheduler {
    private const val ACTION = "np.school.digitalbell.ALARM"

    // Earliest future bell (within the next 8 days) that obeys holiday / weekend rules
    fun nextBell(st: Store.State): Pair<Long, Bell>? {
        if (st.holiday) return null
        val bells = st.schedules[st.mode]?.filter { it.enabled } ?: return null
        val now = Calendar.getInstance()
        var best: Pair<Long, Bell>? = null
        for (d in 0..7) {
            val day = now.clone() as Calendar
            day.add(Calendar.DAY_OF_YEAR, d)
            val dow = day.get(Calendar.DAY_OF_WEEK)
            if (dow == Calendar.SATURDAY && st.satOff) continue
            if (dow == Calendar.SUNDAY && st.sunOff) continue
            for (b in bells) {
                val p = b.time.split(":")
                val h = p.getOrNull(0)?.trim()?.toIntOrNull() ?: continue
                val m = p.getOrNull(1)?.trim()?.toIntOrNull() ?: continue
                val c = day.clone() as Calendar
                c.set(Calendar.HOUR_OF_DAY, h); c.set(Calendar.MINUTE, m)
                c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0)
                val t = c.timeInMillis
                if (t > now.timeInMillis && (best == null || t < best.first)) best = t to b
            }
            if (best != null) break
        }
        return best
    }

    private fun alarmPi(ctx: Context, b: Bell?): PendingIntent {
        val i = Intent(ctx, AlarmReceiver::class.java).setAction(ACTION)
        if (b != null) i.putExtra("label", b.label).putExtra("sound", b.sound).putExtra("duration", b.duration)
        return PendingIntent.getBroadcast(ctx, 1, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    // Sets ONE system alarm clock for the next bell; it re-arms itself after every ring.
    fun scheduleNext(ctx: Context) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val next = nextBell(Store.load(ctx))
        if (next == null) { am.cancel(alarmPi(ctx, null)); return }
        val show = PendingIntent.getActivity(ctx, 3, Intent(ctx, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        am.setAlarmClock(AlarmManager.AlarmClockInfo(next.first, show), alarmPi(ctx, next.second))
    }
}
