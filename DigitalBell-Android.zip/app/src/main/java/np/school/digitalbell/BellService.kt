package np.school.digitalbell

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager

class BellService : Service() {
    companion object {
        const val ACTION_PLAY = "np.school.digitalbell.PLAY"
        const val ACTION_STOP = "np.school.digitalbell.STOP"
        private const val CHANNEL = "bell"
        private const val NID = 42
    }

    private var player: MediaPlayer? = null
    private var wake: PowerManager.WakeLock? = null
    private val handler = Handler(Looper.getMainLooper())
    private val stopper = Runnable { stopPlayback() }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { stopPlayback(); return START_NOT_STICKY }
        val label = intent?.getStringExtra("label") ?: "घण्टी"
        val sound = intent?.getStringExtra("sound") ?: "electric"
        val dur = (intent?.getIntExtra("duration", 5) ?: 5).coerceIn(1, 120)
        goForeground(label)
        try { play(sound, dur) } catch (e: Exception) { stopPlayback() }
        return START_NOT_STICKY
    }

    private fun goForeground(label: String) {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "विद्यालय घण्टी", NotificationManager.IMPORTANCE_HIGH).apply { setSound(null, null) })
        }
        val fl = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        val stopPi = PendingIntent.getService(this, 1, Intent(this, BellService::class.java).setAction(ACTION_STOP), fl)
        val openPi = PendingIntent.getActivity(this, 2, Intent(this, MainActivity::class.java), fl)
        val nb = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL) else Notification.Builder(this)
        val n = nb.setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("🔔 घण्टी बज्दैछ").setContentText(label)
            .setContentIntent(openPi).setOngoing(true)
            .addAction(android.R.drawable.ic_media_pause, "रोक्नुहोस्", stopPi).build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(NID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        else startForeground(NID, n)
    }

    private fun play(sound: String, durationSec: Int) {
        releasePlayer()
        val file = SoundSynth.file(this, sound)
        try { if (wake?.isHeld == true) wake?.release() } catch (_: Exception) {}
        wake = (getSystemService(POWER_SERVICE) as PowerManager)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "digitalbell:ring")
            .apply { acquire((durationSec + 10) * 1000L) }
        val mp = MediaPlayer()
        mp.setAudioAttributes(AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ALARM)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
        mp.setDataSource(file.absolutePath)
        mp.isLooping = true
        mp.setOnErrorListener { _, _, _ -> stopPlayback(); true }
        mp.prepare()
        mp.start()
        player = mp
        handler.removeCallbacks(stopper)
        handler.postDelayed(stopper, durationSec * 1000L)
    }

    private fun releasePlayer() {
        try { player?.stop() } catch (_: Exception) {}
        try { player?.release() } catch (_: Exception) {}
        player = null
    }

    private fun stopPlayback() {
        handler.removeCallbacks(stopper)
        releasePlayer()
        try { if (wake?.isHeld == true) wake?.release() } catch (_: Exception) {}
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        handler.removeCallbacks(stopper)
        releasePlayer()
        try { if (wake?.isHeld == true) wake?.release() } catch (_: Exception) {}
        super.onDestroy()
    }
}
