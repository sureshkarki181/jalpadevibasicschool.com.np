# डिजिटल घण्टी — Android एप

## APK बनाउने सजिलो तरिका (Android Studio नचाहिने)
1. github.com मा मुफ्त खाता खोल्नुहोस् → **New repository** (नाम: DigitalBell, Private हुन्छ) → Create।
2. यो ZIP खोल्नुहोस्। repository मा **Add file → Upload files** थिचेर ZIP भित्रका सबै फोल्डर र फाइल तान्नुहोस् → Commit।
3. `.github/workflows/build.yml` फाइल अपलोड भएन भने: **Add file → Create new file**, नाम `.github/workflows/build.yml` लेख्नुहोस्, र ZIP भित्रको `workflow-build.yml` को सामग्री टाँस्नुहोस् → Commit।
4. **Actions** ट्याब → "Build APK" → हरियो ✓ आएपछि (३–६ मिनेट) त्यसमा थिच्नुहोस् → तल **Artifacts → DigitalBell-APK** डाउनलोड गर्नुहोस्। ZIP भित्र `app-debug.apk` हुन्छ।
5. APK शिक्षकहरूलाई WhatsApp/Viber बाट पठाउनुहोस्।

## फोनमा इन्स्टल गरेपछि (हरेक शिक्षकले एक पटक)
1. APK खोल्दा "अज्ञात स्रोत" को अनुमति माग्छ → दिनुहोस्।
2. एप खोल्दा सूचना (Notification) अनुमति माग्छ → Allow।
3. एपभित्र "ब्याट्री अप्टिमाइजेसन हटाउनुहोस्" थिचेर अनुमति दिनुहोस्।
4. Xiaomi/Oppo/Vivo/Realme/Samsung: फोनको सेटिङमा गएर एपलाई **Autostart** र **Background चल्न** दिनुहोस् (एपलाई Lock/Pin गर्दा पनि राम्रो हुन्छ)।
5. Alarm volume ठिक राख्नुहोस्।
6. वेब पेजको ब्याकअप (Export JSON) WhatsApp बाट पठाएर एपमा "इम्पोर्ट" गर्नुहोस्।

नोट: वेब पेजको "शनिबार र आइतबार स्वतः बन्द" इम्पोर्ट गर्दा दुवै बन्द हुन्छ। आइतबार विद्यालय खुल्छ भने एपमा "आइतबार घण्टी बन्द" बन्द गर्नुहोस्।
